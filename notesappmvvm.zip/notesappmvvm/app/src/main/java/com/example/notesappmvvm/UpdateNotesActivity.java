package com.example.notesappmvvm;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.notesappmvvm.Model.Notes;
import com.example.notesappmvvm.ViewModel.NotesViewModel;
import com.example.notesappmvvm.databinding.ActivityInsertNotesBinding;
import com.example.notesappmvvm.databinding.ActivityUpdateNotesBinding;

public class UpdateNotesActivity extends AppCompatActivity {
    ActivityUpdateNotesBinding binding;
    String priority = "1";
    String stitle,ssubtitle,snotes,spriority;
    int iid;
    NotesViewModel notesViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_notes);
        binding= ActivityUpdateNotesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        iid=getIntent().getIntExtra("id",0);
        stitle=getIntent().getStringExtra("title");
        ssubtitle=getIntent().getStringExtra("subtitle");
        spriority=getIntent().getStringExtra("priority");
        snotes=getIntent().getStringExtra("note");
        
        binding.upTitle.setText(stitle);
        binding.upSubtitle.setText(ssubtitle);
        binding.upNotes.setText(snotes);
        
        if(spriority.equals("1")){
            binding.greenPriority.setImageResource(R.drawable.ic_baseline_done_24);
        }
        else if(spriority.equals("2")){
            binding.yellowPriority.setImageResource(R.drawable.ic_baseline_done_24);
        }
        else if(spriority.equals("3")){
            binding.redPriority.setImageResource(R.drawable.ic_baseline_done_24);
        }
        notesViewModel = new ViewModelProvider(UpdateNotesActivity.this).get(NotesViewModel.class);
        binding.greenPriority.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.greenPriority.setImageResource(R.drawable.ic_baseline_done_24);
                binding.redPriority.setImageResource(0);
                binding.yellowPriority.setImageResource(0);
                priority = "1";
            }
        });
        binding.yellowPriority.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                priority = "2";
                binding.yellowPriority.setImageResource(R.drawable.ic_baseline_done_24);
                binding.redPriority.setImageResource(0);
                binding.greenPriority.setImageResource(0);
            }
        });
        binding.redPriority.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.redPriority.setImageResource(R.drawable.ic_baseline_done_24);
                binding.yellowPriority.setImageResource(0);
                binding.greenPriority.setImageResource(0);
                priority = "3";
            }
        });
        binding.updateNotesbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title=binding.upNotes.getText().toString();
                String subtitle=binding.upSubtitle.getText().toString();
                String notes=binding.upNotes.getText().toString();
                UpdateNotes(title,subtitle,notes);
            }

            private void UpdateNotes(String title, String subtitle, String notes) {
                Notes updateNotes = new Notes();
                updateNotes.id=iid;
                updateNotes.notesTitle=title;
                updateNotes.noteSubtitle=subtitle;
                updateNotes.notes=notes;
                updateNotes.notesPriority = priority;
                notesViewModel.updateNote(updateNotes);
                Toast.makeText(UpdateNotesActivity.this, "Notes Updated Successfully",Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}