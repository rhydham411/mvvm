package com.example.notesappmvvm;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.notesappmvvm.Adapter.NotesAdapter;
import com.example.notesappmvvm.ViewModel.NotesViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
FloatingActionButton newNotesbtn;
    NotesViewModel notesViewModel;
    RecyclerView notesRecycler;
    NotesAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        newNotesbtn.findViewById(R.id.newNotesbtn);
        notesRecycler = findViewById(R.id.notesRecycler);
        notesViewModel = new ViewModelProvider(MainActivity.this).get(NotesViewModel.class);
        newNotesbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,InsertNotesActivity.class));
            }
        });
        notesViewModel.getAllNotes.observe(MainActivity.this,notes -> {
        notesRecycler.setLayoutManager(new GridLayoutManager(MainActivity.this,2));
        adapter=new NotesAdapter(MainActivity.this,notes);
        notesRecycler.setAdapter(adapter);
        });
    }
}